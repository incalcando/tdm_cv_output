/**
 * \defgroup hardware_dcp hardware_dcp
 * \brief Assembly macros for the Double Coprocessor
 */
